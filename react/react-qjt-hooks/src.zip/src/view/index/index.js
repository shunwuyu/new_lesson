import React from 'react';

const Index = () => {
  return (
    <>
    Index
    </>
  )
}

export default Index;